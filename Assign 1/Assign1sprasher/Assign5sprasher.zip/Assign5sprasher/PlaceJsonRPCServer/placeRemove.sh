curl --data "{ \"jsonrpc\": \"2.0\", \"method\": \"remove\", \"params\": [\"ASU-Poly\"], \"id\": 3}" localhost:8080
