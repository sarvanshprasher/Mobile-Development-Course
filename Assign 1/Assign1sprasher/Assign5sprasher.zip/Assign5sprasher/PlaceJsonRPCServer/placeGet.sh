curl --data "{ \"jsonrpc\": \"2.0\", \"method\": \"get\", \"params\": [\"ASU-Poly\"], \"id\": 3}" localhost:8080
